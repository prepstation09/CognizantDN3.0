package com.example.BookstoreAPI.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerDTO {
	private Long id;
    private String name;
    private String email;
}
