package com.example.EmployeeManagementSystem.projection;

public interface EmployeeProjection {
	 String getName();
	 String getEmail();
}
